// ═══════════════════════════════════════════════════════════════
// INDIA MONITOR — MapLibre GL Map
// map.js
//
// Add to your index.html:
//   1. In <head>, add BEFORE your existing scripts:
//      <link rel="stylesheet" href="https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css">
//      <script src="https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js"></script>
//
//   2. Replace <canvas id="mc"></canvas> with:
//      <div id="glMap" style="width:100%;height:100%"></div>
//
//   3. Add BEFORE </div> of the .mw container (after legend .ml div):
//      <div class="map-styles">
//        <button class="map-style-btn on" onclick="setMapStyle('dark',this)">🌑 Dark</button>
//        <button class="map-style-btn" onclick="setMapStyle('satellite',this)">🛰️ Satellite</button>
//        <button class="map-style-btn" onclick="setMapStyle('streets',this)">🗺️ Streets</button>
//        <button class="map-style-btn" onclick="setMapStyle('3d',this)">🏔️ 3D</button>
//      </div>
//
//   4. At end of <body>, add:
//      <script src="map.js"></script>
//
//   5. REMOVE all old canvas map code from your inline <script>:
//      - Remove everything from "// CANVAS MAP" to end of fly() / tL() / rsz() / drw()
//      - Remove the variables: cv, cx, W, H, cX, cY, zm, pX, pY, dr, dX, dY, af,
//        ctr, AL, dynMarkers, MK, IO, states, stateRegions, cities, rivers, neighbors,
//        andaman, srilanka, lakshadweep
//      - Keep the AL object declaration (or this file re-declares it)
//
//   6. Update your fly() calls in the region buttons:
//      Old: onclick="fly(22.5,82,1,this)"
//      New: onclick="fly(22.5,82,4.2,this)"
//      (MapLibre uses zoom levels 0-22, not your custom scale)
//
//      Suggested zoom mappings:
//        ALL INDIA → fly(22.5, 82, 4.2, this)
//        J&K       → fly(34.1, 74.8, 8, this)
//        NE        → fly(26, 93, 6.5, this)
//        NCR       → fly(28.6, 77.2, 10, this)
//        MUMBAI    → fly(19.1, 72.9, 10, this)
//        BLR       → fly(13, 77.6, 10, this)
//        KOL       → fly(22.6, 88.4, 10, this)
//        NAXAL     → fly(20, 82, 5.5, this)
// ═══════════════════════════════════════════════════════════════

(function() {
  'use strict';

  // ─── Map tile styles ───
  const STYLES = {
    dark: {
      version: 8,
      sources: {
        'carto-dark': {
          type: 'raster',
          tiles: ['https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png'],
          tileSize: 256,
          attribution: '&copy; <a href="https://carto.com">CARTO</a> &copy; <a href="https://osm.org">OSM</a>'
        }
      },
      layers: [{ id: 'carto-dark', type: 'raster', source: 'carto-dark' }]
    },
    satellite: {
      version: 8,
      sources: {
        'esri-sat': {
          type: 'raster',
          tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],
          tileSize: 256,
          attribution: '&copy; Esri, Maxar, Earthstar'
        }
      },
      layers: [{ id: 'esri-sat', type: 'raster', source: 'esri-sat' }]
    },
    streets: {
      version: 8,
      sources: {
        'carto-light': {
          type: 'raster',
          tiles: ['https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png'],
          tileSize: 256,
          attribution: '&copy; <a href="https://carto.com">CARTO</a> &copy; <a href="https://osm.org">OSM</a>'
        }
      },
      layers: [{ id: 'carto-light', type: 'raster', source: 'carto-light' }]
    }
  };

  // ─── Marker data ───
  const MARKERS = [
    // Conflict zones
    { lat: 34.08, lng: 74.79, color: '#ef4444', label: 'LoC — Active Sector',       sub: 'Ceasefire monitoring zone',    type: 'conflict', pulse: true },
    { lat: 33.73, lng: 74.35, color: '#ef4444', label: 'Poonch — Alert Zone',        sub: 'Border district alert',        type: 'conflict', pulse: true },
    { lat: 34.52, lng: 74.53, color: '#ef4444', label: 'Kupwara — Infiltration',     sub: 'Forward area operations',      type: 'conflict', pulse: true },
    { lat: 19.50, lng: 82.50, color: '#ef4444', label: 'Bastar — Naxal Zone',        sub: 'LWE affected district',        type: 'conflict', pulse: true },
    { lat: 25.50, lng: 93.50, color: '#f59e0b', label: 'Manipur — Unrest',           sub: 'Ethnic conflict zone',         type: 'conflict', pulse: true },
    // Military
    { lat: 28.60, lng: 77.10, color: '#ff9933', label: 'Delhi — Army HQ',            sub: 'Integrated Defence Staff',     type: 'military' },
    { lat: 17.40, lng: 78.50, color: '#ff9933', label: 'Secunderabad — SC',          sub: 'Southern Command HQ',          type: 'military' },
    { lat: 17.70, lng: 83.30, color: '#3b82f6', label: 'Visakhapatnam — ENC',        sub: 'Eastern Naval Command',        type: 'military' },
    { lat: 18.95, lng: 72.84, color: '#3b82f6', label: 'Mumbai — WNC',               sub: 'Western Naval Command',        type: 'military' },
    { lat: 8.48,  lng: 76.95, color: '#3b82f6', label: 'Thiruvananthapuram — SNC',   sub: 'Southern Naval Command',       type: 'military' },
    { lat: 26.30, lng: 73.02, color: '#ff9933', label: 'Jodhpur — SWAC',             sub: 'South Western Air Command',    type: 'military' },
    { lat: 11.75, lng: 92.73, color: '#3b82f6', label: 'Port Blair — ANC',           sub: 'Andaman & Nicobar Command',    type: 'military' },
    // Infrastructure
    { lat: 13.72, lng: 80.23, color: '#f59e0b', label: 'Kalpakkam Nuclear',          sub: 'MAPS + PFBR reactors',         type: 'infra' },
    { lat: 19.07, lng: 72.88, color: '#06b6d4', label: 'Mumbai — Cable Hub',         sub: 'Submarine internet gateway',   type: 'infra' },
    { lat: 12.97, lng: 77.59, color: '#06b6d4', label: 'Bengaluru — AI Hub',         sub: 'Defence R&D cluster',          type: 'infra' },
    { lat: 13.73, lng: 80.19, color: '#f59e0b', label: 'ISRO Sriharikota',           sub: 'Satish Dhawan Space Centre',   type: 'infra' },
    { lat: 24.58, lng: 93.90, color: '#f59e0b', label: 'Moreh — Border Trade',       sub: 'India-Myanmar trade point',    type: 'infra' },
  ];

  // ─── Layer toggle state ───
  // If AL already exists globally (from your existing code), use it; otherwise create it
  if (typeof window.AL === 'undefined') {
    window.AL = { conflict: true, military: true, infra: true, disaster: true, flights: true };
  } else {
    window.AL.flights = true;
  }

  // ─── Flight marker store ───
  var flightMarkers = [];

  // ─── Animated plane icon (SVG, rotates with heading) ───
  function createPlaneEl(heading) {
    var el = document.createElement('div');
    el.style.cssText = 'width:20px;height:20px;cursor:pointer;transition:transform 0.8s ease;';
    el.style.transform = 'rotate(' + (heading || 0) + 'deg)';
    el.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" xmlns="http://www.w3.org/2000/svg">'
      + '<path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"'
      + ' fill="#3b82f6" stroke="#1d4ed8" stroke-width="0.5"/>'
      + '</svg>';
    return el;
  }

  // ─── State ───
  let map;
  let currentStyle = 'dark';
  const activeMarkers = [];

  // ─── Initialize Map ───
  function initMap() {
    const isLight = document.documentElement.getAttribute('data-theme') === 'light';
    currentStyle = isLight ? 'streets' : 'dark';

    map = new maplibregl.Map({
      container: 'glMap',
      style: STYLES[currentStyle],
      center: [82, 22.5],
      zoom: 4.2,
      minZoom: 3,
      maxZoom: 18,
      maxBounds: [[55, 2], [105, 40]],
      attributionControl: false,
      pitchWithRotate: true,
      dragRotate: true,
      touchPitch: true,
    });

    // Navigation controls (zoom + compass) — positioned where they won't overlap legend
    map.addControl(
      new maplibregl.NavigationControl({ showCompass: true, showZoom: true, visualizePitch: true }),
      'top-right'
    );

    // Compact attribution
    map.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-right');

    // Scale bar
    map.addControl(new maplibregl.ScaleControl({ maxWidth: 100, unit: 'metric' }), 'bottom-left');

    // Custom + / - zoom buttons (styled to match dashboard)
    var zoomBox = document.createElement('div');
    zoomBox.className = 'im-zoom-ctrl';
    zoomBox.innerHTML =
      '<button onclick="window._imMap.zoomIn({duration:300})" title="Zoom In">+</button>' +
      '<button onclick="window._imMap.zoomOut({duration:300})" title="Zoom Out">\u2212</button>' +
      '<button onclick="window._imMap.flyTo({center:[82,22.5],zoom:4.2,duration:800})" title="Reset">\u2302</button>';
    document.getElementById('glMap').parentElement.appendChild(zoomBox);

    // Hide default MapLibre nav buttons (we have custom ones now)
    var style = document.createElement('style');
    style.textContent =
      '.maplibregl-ctrl-top-right .maplibregl-ctrl-group{display:none}' +
      '.im-zoom-ctrl{position:absolute;top:50%;right:10px;transform:translateY(-50%);z-index:5;display:flex;flex-direction:column;gap:2px}' +
      '.im-zoom-ctrl button{width:32px;height:32px;border:1px solid var(--brd);background:rgba(15,22,35,.9);color:var(--t2);font-family:var(--fm);font-size:1rem;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);line-height:1}' +
      '.im-zoom-ctrl button:hover{background:rgba(255,153,51,.12);border-color:var(--saf);color:var(--saf)}' +
      '.im-zoom-ctrl button:active{transform:scale(.92)}' +
      '[data-theme="light"] .im-zoom-ctrl button{background:rgba(255,255,255,.92);color:#374151;border-color:#c8cdd6}' +
      '[data-theme="light"] .im-zoom-ctrl button:hover{background:rgba(180,83,9,.1);color:#92400e;border-color:var(--saf)}' +
      '@media(max-width:768px){.im-zoom-ctrl{right:6px}.im-zoom-ctrl button{width:36px;height:36px;font-size:1.1rem}}';
    document.head.appendChild(style);

    // Add markers once map loads
    map.on('load', function() {
      addAllMarkers();
      highlightActiveStyleBtn();
    });

    // Store globally for other scripts
    window._imMap = map;
  }

  // ─── Create a custom marker DOM element ───
  function createMarkerEl(mk) {
    const size = mk.pulse ? 20 : 16;
    const el = document.createElement('div');
    el.style.cssText = 'position:relative;cursor:pointer;width:' + size + 'px;height:' + size + 'px;';

    // Outer glow ring
    const ring = document.createElement('div');
    ring.style.cssText =
      'position:absolute;inset:0;border-radius:50%;' +
      'background:' + mk.color + '25;' +
      'border:2px solid ' + mk.color + '80;' +
      'transition:transform .2s ease,box-shadow .2s ease;';
    el.appendChild(ring);

    // Inner solid dot
    const dot = document.createElement('div');
    dot.style.cssText =
      'position:absolute;top:50%;left:50%;' +
      'width:' + (size * 0.4) + 'px;height:' + (size * 0.4) + 'px;' +
      'border-radius:50%;background:' + mk.color + ';' +
      'transform:translate(-50%,-50%);' +
      'box-shadow:0 0 8px ' + mk.color + '90;';
    el.appendChild(dot);

    // Pulse ring for conflict/alert markers
    if (mk.pulse) {
      const pulse = document.createElement('div');
      pulse.style.cssText =
        'position:absolute;top:50%;left:50%;' +
        'width:' + size + 'px;height:' + size + 'px;' +
        'border-radius:50%;border:1.5px solid ' + mk.color + ';' +
        'transform:translate(-50%,-50%);' +
        'animation:mapMarkerPulse 2s ease-out infinite;opacity:0;';
      el.appendChild(pulse);
    }

    // Hover effect
    el.addEventListener('mouseenter', function() {
      ring.style.transform = 'scale(1.4)';
      ring.style.boxShadow = '0 0 12px ' + mk.color + '60';
    });
    el.addEventListener('mouseleave', function() {
      ring.style.transform = 'scale(1)';
      ring.style.boxShadow = 'none';
    });

    return el;
  }

  // ─── Add all markers based on active layers ───
  function addAllMarkers() {
    // Remove existing
    activeMarkers.forEach(function(m) { m.remove(); });
    activeMarkers.length = 0;

    MARKERS.forEach(function(mk) {
      // Check layer toggle
      if (!window.AL[mk.type]) return;

      var el = createMarkerEl(mk);

      // Popup content
      var popup = new maplibregl.Popup({
        offset: 14,
        closeButton: true,
        closeOnClick: true,
        maxWidth: '240px',
        className: 'im-popup'
      }).setHTML(
        '<div class="map-popup-title">' + mk.label + '</div>' +
        '<div class="map-popup-sub">' + (mk.sub || mk.type.toUpperCase()) + '</div>'
      );

      var marker = new maplibregl.Marker({ element: el, anchor: 'center' })
        .setLngLat([mk.lng, mk.lat])
        .setPopup(popup)
        .addTo(map);

      activeMarkers.push(marker);
    });
  }

  // ─── Style switching ───
  function highlightActiveStyleBtn() {
    document.querySelectorAll('.map-style-btn').forEach(function(btn) {
      btn.classList.remove('on');
      var text = btn.textContent.toLowerCase();
      if (text.indexOf(currentStyle) !== -1) btn.classList.add('on');
      // Special: dark mode btn active by default
      if (currentStyle === 'dark' && text.indexOf('dark') !== -1) btn.classList.add('on');
      if (currentStyle === 'streets' && text.indexOf('street') !== -1) btn.classList.add('on');
    });
  }

  window.setMapStyle = function(style, btn) {
    if (style === '3d') {
      // Toggle 3D pitch
      var pitch = map.getPitch();
      if (pitch > 10) {
        map.easeTo({ pitch: 0, bearing: 0, duration: 800 });
      } else {
        map.easeTo({ pitch: 55, bearing: -15, duration: 1000 });
      }
      return;
    }

    if (!STYLES[style]) return;
    currentStyle = style;
    map.setStyle(STYLES[style]);

    // Re-add markers after style change (tiles reload destroys overlay)
    map.once('styledata', function() {
      addAllMarkers();
      // Re-render flight markers if available
      if (typeof window.loadFlights === 'function') window.loadFlights();
    });

    // Update active button
    if (btn) {
      document.querySelectorAll('.map-style-btn').forEach(function(b) { b.classList.remove('on'); });
      btn.classList.add('on');
    }
  };

  // ─── Fly to location (called by region nav buttons) ───
  window.fly = function(lat, lng, zoom, btn) {
    // Update active button
    document.querySelectorAll('.rb').forEach(function(b) { b.classList.remove('on'); });
    if (btn) btn.classList.add('on');

    map.flyTo({
      center: [lng, lat],
      zoom: zoom,
      duration: 1500,
      essential: true,
      curve: 1.42,
    });
  };

  // ─── Layer toggle (called by overlay buttons) ───
  window.tL = function(btn) {
    btn.classList.toggle('on');
    window.AL[btn.dataset.ly] = btn.classList.contains('on');
    addAllMarkers();
  };

  // ─── Theme integration ───
  // When theme toggles, switch map style too
  var origToggleTheme = window.toggleTheme;
  window.toggleTheme = function() {
    // Call original theme toggle
    if (typeof origToggleTheme === 'function') {
      origToggleTheme();
    }
    // Auto-switch map style with theme (unless on satellite)
    if (currentStyle !== 'satellite') {
      var isNowLight = document.documentElement.getAttribute('data-theme') === 'light';
      window.setMapStyle(isNowLight ? 'streets' : 'dark');
    }
  };

  // ─── Expose for external use ───
  window.addAllMarkers = addAllMarkers;
  window._mapCurrentStyle = function() { return currentStyle; };

  // ─── Flight marker management ───
  window.updateFlightMarkers = function(ac) {
    // Remove old flight markers
    flightMarkers.forEach(function(m) { m.remove(); });
    flightMarkers = [];

    if (!window.AL.flights) return;

    ac.forEach(function(a) {
      var lon = a.lon != null ? parseFloat(a.lon) : null;
      var lat = a.lat != null ? parseFloat(a.lat) : null;
      if (lon == null || lat == null || isNaN(lon) || isNaN(lat)) return;

      var callsign = (a.flight || a.r || a.hex || 'N/A').trim();
      var heading  = a.track != null ? parseFloat(a.track) : 0;
      var altFt    = typeof a.alt_baro === 'number' ? a.alt_baro : null;
      var altKm    = altFt != null ? (altFt * 0.0003048).toFixed(1) + ' km' : '—';
      var spd      = a.gs  != null ? Math.round(parseFloat(a.gs) * 1.852) + ' km/h' : '—';
      var type     = a.t || '';

      var el = createPlaneEl(heading);

      var popup = new maplibregl.Popup({
        offset: 12,
        closeButton: true,
        closeOnClick: true,
        maxWidth: '210px',
        className: 'im-popup'
      }).setHTML(
        '<div class="map-popup-title">✈️ ' + callsign + (type ? ' · ' + type : '') + '</div>'
        + '<div class="map-popup-sub">'
        + 'Alt: ' + altKm + ' · ' + spd
        + '</div>'
      );

      var marker = new maplibregl.Marker({ element: el, anchor: 'center' })
        .setLngLat([lon, lat])
        .setPopup(popup)
        .addTo(map);

      flightMarkers.push(marker);
    });
  };

  // Hook flights toggle into tL
  var origTL = window.tL;
  window.tL = function(btn) {
    btn.classList.toggle('on');
    window.AL[btn.dataset.ly] = btn.classList.contains('on');
    if (btn.dataset.ly === 'flights') {
      if (!window.AL.flights) {
        flightMarkers.forEach(function(m) { m.remove(); });
        flightMarkers = [];
      }
      // Toggling on: wait for next loadFlights() call
    } else {
      addAllMarkers();
    }
  };

  // ─── Init ───
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMap);
  } else {
    initMap();
  }

})();
